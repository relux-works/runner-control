import Foundation
import Relux
import RunnerControlCore

enum FixtureError: Error { case stop }
actor DownloadBarrier {
    var entered = 0
    var released = false
    func download() async throws -> Data {
        entered += 1
        while !released { try await Task.sleep(for: .milliseconds(5)) }
        throw FixtureError.stop
    }
    func count() -> Int { entered }
    func release() { released = true }
}
actor RefreshTransport: GitHubHTTPTransport {
    var refreshCalls = 0
    var releaseFirst = false
    var releaseSecond = false
    func send(_ request: GitHubHTTPRequest) async throws -> GitHubHTTPResponse {
        if request.method == "POST" {
            refreshCalls += 1
            let n = refreshCalls
            if n == 1 {
                while !releaseFirst { try await Task.sleep(for: .milliseconds(5)) }
                return response(#"{"access_token":"ghu_fixture_new","refresh_token":"ghr_fixture_new","expires_in":3600}"#)
            }
            while !releaseSecond { try await Task.sleep(for: .milliseconds(5)) }
            return response(#"{"error":"invalid_grant"}"#)
        }
        if request.url.path == "/user" { return response(#"{"login":"fixture","id":42}"#) }
        return response(#"{"installations":[]}"#)
    }
    func response(_ text: String) -> GitHubHTTPResponse {
        GitHubHTTPResponse(status: 200, headers: [:], body: Data(text.utf8))
    }
    func count() -> Int { refreshCalls }
    func first() { releaseFirst = true }
    func second() { releaseSecond = true }
}
@main struct ReviewDriver {
    static func main() async throws {
        let mode = CommandLine.arguments[1]
        if mode == "lock" { try await lockProbe(broken: false); try await lockProbe(broken: true) }
        if mode == "refresh" { try await refreshProbe() }
    }
    static func lockProbe(broken: Bool) async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent("TASK-260922-2qddb7-lock-" + UUID().uuidString)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: root) }
        if broken { try FileManager.default.createDirectory(at: root.appendingPathComponent(".runnercontrol-installer.lock"), withIntermediateDirectories: true) }
        let barrier = DownloadBarrier()
        let a = RunnerInstallerService(installRoot: root, downloader: { _ in try await barrier.download() })
        let b = RunnerInstallerService(installRoot: root, downloader: { _ in try await barrier.download() })
        let asset = RunnerRegistration.DownloadAsset(osName: "osx", architecture: "arm64", downloadURL: URL(string: "https://fixture.invalid/runner.tgz")!, filename: "runner.tgz", sha256Checksum: "fixture")
        let draft = RunnerRegistration.Draft(scope: .repository(owner: "fixture", name: "repo"), runnerName: "fixture", installDirName: "fixture")
        let first = Task { do { _ = try await a.downloadAndInstall(asset: asset, draft: draft); return "success" } catch { return String(describing: error) } }
        for _ in 0..<400 { if await barrier.count() >= 1 { break }; try await Task.sleep(for: .milliseconds(5)) }
        let second = Task { do { _ = try await b.downloadAndInstall(asset: asset, draft: draft); return "success" } catch { return String(describing: error) } }
        try await Task.sleep(for: .milliseconds(150))
        let admitted = await barrier.count()
        await barrier.release()
        let r1 = await first.value; let r2 = await second.value
        print("lock_unopenable=\(broken) admitted_downloads=\(admitted) first=\(r1) second=\(r2)")
        print("CONTRACT_ASSERT no_two_downloaders=\(admitted <= 1)")
        if admitted > 1 { Foundation.exit(1) }
    }
    static func refreshProbe() async throws {
        let store = GitHubKeychainStore(backend: InMemoryKeychainBackend())
        let config = GitHubAuth.AppConfig(clientID: "REVIEW_FIXTURE", serverHost: "github.com")
        let identities = InMemoryGitHubSessionIdentityStore(value: GitHubSessionIdentity(serverHost: "github.com", userID: 42, clientID: config.clientID, username: "fixture"))
        try await store.save(GitHubAuth.TokenRecord(accessToken: "ghu_fixture_old", refreshToken: "ghr_fixture_old", expiresAt: Date().addingTimeInterval(-1), obtainedAt: Date()), serverHost: "github.com", userID: 42, clientID: config.clientID)
        let transport = RefreshTransport()
        func flow() async -> GitHubAuth.Flow {
            let logger = Relux.Testing.Logger()
            return await GitHubAuth.Flow(deviceFlow: GitHubDeviceFlow(transport: transport), api: GitHubAPIClient(transport: transport), refresher: GitHubTokenRefresh(transport: transport, store: store), store: store, identityStore: identities, configProvider: { _ in config }, dispatcher: Relux.Dispatcher(logger: logger))
        }
        let a = await flow(); let b = await flow()
        let first = Task { await a.apply(GitHubAuth.Effect.restoreSession) }
        for _ in 0..<400 { if await transport.count() >= 1 { break }; try await Task.sleep(for: .milliseconds(5)) }
        let second = Task { await b.apply(GitHubAuth.Effect.restoreSession) }
        for _ in 0..<400 { if await transport.count() >= 2 { break }; try await Task.sleep(for: .milliseconds(5)) }
        await transport.first(); _ = await first.value
        let before = await store.load(serverHost: "github.com", userID: 42, clientID: config.clientID) != nil
        await transport.second(); _ = await second.value
        let after = await store.load(serverHost: "github.com", userID: 42, clientID: config.clientID) != nil
        let identityAfter = await identities.load() != nil
        print("refresh_requests=\(await transport.count()) token_after_winner=\(before) token_after_loser=\(after) identity_after_loser=\(identityAfter)")
        print("CONTRACT_ASSERT newer_shared_session_survives=\(after && identityAfter)")
        if !after || !identityAfter { Foundation.exit(1) }
    }
}

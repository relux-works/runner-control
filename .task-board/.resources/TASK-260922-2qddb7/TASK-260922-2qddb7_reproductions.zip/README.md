# Replay review probes

Candidate is fb85df52b7ed74a05725ac4be3c2b0668aff54a8 plus candidate/ files pinned by candidate-sha256.json. The repository candidate was not edited. Restore these bytes only in a disposable checkout if replaying later.

From candidate repo root:

```
swift build --package-path Packages/RunnerControlCLI --scratch-path /tmp/TASK-260922-2qddb7-build --disable-automatic-resolution --product runner-control
```

From extracted reproduction directory (compile-driver.py links the exact production Core and Relux object files; no production gate is copied or faked):

```
python3 compile-driver.py
./review-driver lock
./review-driver refresh
python3 blackbox.py json
python3 blackbox.py path
python3 blackbox.py network
```

Each probe command should exit 1 on this rejected candidate, naming the false contract assertion. lock includes a normal-contention control. path includes regular-file/foreign-link refusal controls. json includes a CLIFailure control. Default binary path can be overridden with --binary. All mutable fixtures are temporary, session stores are in-memory, downloader returns no archive, and network probe uses loopback only. No real auth, runner, launchd, Keychain, or shared plist mutation is needed.

For commands/complete outputs of passing repository subsets see suite-evidence.log, core-suite.log, packaging-suite.log. For failing probes see lock.log, refresh.log, json.log, path.log, network.log. sha256 manifest and candidate/ preserve the reviewed blobs. verdict.json is the structured findings array and surface table.

from pathlib import Path
import subprocess,sys
root=Path(sys.argv[1] if len(sys.argv)>1 else '/tmp/TASK-260922-2qddb7-build/arm64-apple-macosx/debug')
here=Path(__file__).parent
objects=list((root/'RunnerControlCore.build').glob('*.swift.o'))+list((root/'Relux.build').glob('*.swift.o'))
assert objects
subprocess.run(['swiftc','-parse-as-library','-I',str(root/'Modules'),str(here/'review-driver.swift'),*map(str,objects),'-o',str(here/'review-driver')],check=True)

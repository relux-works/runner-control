import argparse, subprocess, tempfile, pathlib, json, os, plistlib, shutil, socket
parser=argparse.ArgumentParser()
parser.add_argument('mode', choices=['json','path','network'])
parser.add_argument('--binary', default='/tmp/TASK-260922-2qddb7-build/debug/runner-control')
a=parser.parse_args(); b=str(pathlib.Path(a.binary).resolve()); failures=[]
def invoke(args, **kw):
 p=subprocess.run(args, capture_output=True, text=True, timeout=10, **kw)
 print(json.dumps({'args':args,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}))
 return p
def check(ok, message):
 print(('PASS ' if ok else 'FAIL ')+message)
 if not ok: failures.append(message)
if a.mode=='json':
 for args in [['app','version','--bogus','--json'],['auth','installation','not-int','--json'],['runners','alias','--json']]:
  p=invoke([b,*args]); check(p.returncode==1, 'usage exits 1')
  try: doc=json.loads(p.stdout); ok=doc.get('status')=='error'
  except ValueError: ok=False
  check(ok, 'usage emits one JSON error')
 p=invoke([b,'app','auto-check','bogus','--json'])
 check(p.returncode==1 and json.loads(p.stdout)['status']=='error','custom validation control')
if a.mode=='path':
 with tempfile.TemporaryDirectory(prefix='TASK-260922-2qddb7-path-') as td:
  root=pathlib.Path(td); (root/'bin').mkdir(); (root/'bin/runner-control').symlink_to(b)
  env=os.environ.copy(); env['PATH']=str(root/'bin')+':'+env['PATH']
  p=invoke(['runner-control','app','version','--json'],cwd=td,env=env)
  check(pathlib.Path(json.loads(p.stdout)['data']['cli']).resolve()==pathlib.Path(b),'version reports actual executable under PATH')
  link=root/'link'; p=invoke(['runner-control','app','install-cli','--location',str(link),'--json'],cwd=td,env=env)
  check(p.returncode==0 and link.exists() and link.resolve()==pathlib.Path(b),'successful PATH self-install produces working link')
  regular=root/'regular'; regular.write_text('keep')
  p=invoke([b,'app','install-cli','--location',str(regular),'--json'])
  check(p.returncode==2 and regular.read_text()=='keep','regular file refusal control')
  foreign=root/'foreign'; foreign.symlink_to('/usr/bin/false')
  p=invoke([b,'app','uninstall-cli','--location',str(foreign),'--json'])
  check(p.returncode==2 and os.readlink(foreign)=='/usr/bin/false','foreign symlink refusal control')
if a.mode=='network':
 with tempfile.TemporaryDirectory(prefix='TASK-260922-2qddb7-net-') as td:
  root=pathlib.Path(td); app=root/'Fixture.app/Contents'; helper=app/'Helpers/runner-control'; helper.parent.mkdir(parents=True)
  shutil.copy2(b,helper)
  sock=socket.socket(); sock.bind(('127.0.0.1',0)); port=sock.getsockname()[1]
  # Bound but not listening: deterministic refused connection, no remote request.
  (app/'Info.plist').write_bytes(plistlib.dumps({'SUFeedURL':f'http://127.0.0.1:{port}/appcast.xml','CFBundleShortVersionString':'1.0.0'}))
  p=invoke([str(helper),'app','check-updates','--json']); sock.close()
  check(p.returncode==2,'network operation failure exits 2')
  try: ok=json.loads(p.stdout)['status']=='error'
  except ValueError: ok=False
  check(ok,'network operation failure emits JSON')
raise SystemExit(bool(failures))

import Foundation
import Testing
@testable import RunnerControlCore

// MARK: - CLIInstallerService (symlink install into PATH)

private func installerFixture() throws -> (root: URL, target: URL) {
    let root = FileManager.default.temporaryDirectory.appendingPathComponent("RC-CLI-" + UUID().uuidString)
    try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
    let target = root.appendingPathComponent("runner-control")
    try "#!/bin/sh\n".write(to: target, atomically: true, encoding: .utf8)
    try FileManager.default.setAttributes([.posixPermissions: 0o755], ofItemAtPath: target.path)
    return (root, target)
}

@Test func installCreatesSymlinkAndIsIdempotent() throws {
    let fixture = try installerFixture()
    defer { try? FileManager.default.removeItem(at: fixture.root) }
    let link = fixture.root.appendingPathComponent("bin/runner-control").path
    #expect(CLIInstallerService.status(linkPath: link, target: fixture.target) == .missing)
    try CLIInstallerService.install(target: fixture.target, linkPath: link)
    #expect(CLIInstallerService.status(linkPath: link, target: fixture.target) == .installedCurrent)
    // Second install is a no-op, not an error.
    try CLIInstallerService.install(target: fixture.target, linkPath: link)
    #expect(CLIInstallerService.status(linkPath: link, target: fixture.target) == .installedCurrent)
}

@Test func installRefusesNonSymlink() throws {
    let fixture = try installerFixture()
    defer { try? FileManager.default.removeItem(at: fixture.root) }
    let link = fixture.root.appendingPathComponent("runner-control").path
    try "foreign".write(to: URL(fileURLWithPath: link), atomically: true, encoding: .utf8)
    #expect(CLIInstallerService.status(linkPath: link, target: fixture.target) == .blockedByFile)
    do {
        try CLIInstallerService.install(target: fixture.target, linkPath: link)
        Issue.record("expected blockedByFile")
    } catch let error as CLIInstallerService.InstallError {
        #expect(error == .blockedByFile(path: link))
    }
    #expect((try? String(contentsOf: URL(fileURLWithPath: link), encoding: .utf8)) == "foreign")
}

@Test func installAdoptsForeignSymlink() throws {
    let fixture = try installerFixture()
    defer { try? FileManager.default.removeItem(at: fixture.root) }
    let link = fixture.root.appendingPathComponent("bin/runner-control").path
    try FileManager.default.createDirectory(at: URL(fileURLWithPath: link).deletingLastPathComponent(), withIntermediateDirectories: true)
    try FileManager.default.createSymbolicLink(atPath: link, withDestinationPath: "/usr/bin/false")
    if case .installedOther = CLIInstallerService.status(linkPath: link, target: fixture.target) {
    } else {
        Issue.record("expected installedOther")
    }
    try CLIInstallerService.install(target: fixture.target, linkPath: link)
    #expect(CLIInstallerService.status(linkPath: link, target: fixture.target) == .installedCurrent)
}

@Test func uninstallRemovesOnlyOwnSymlink() throws {
    let fixture = try installerFixture()
    defer { try? FileManager.default.removeItem(at: fixture.root) }
    let own = fixture.root.appendingPathComponent("own").path
    try CLIInstallerService.install(target: fixture.target, linkPath: own)
    try CLIInstallerService.uninstall(target: fixture.target, linkPath: own)
    #expect(CLIInstallerService.status(linkPath: own, target: fixture.target) == .missing)
    // Missing link: no-op.
    try CLIInstallerService.uninstall(target: fixture.target, linkPath: own)

    let foreign = fixture.root.appendingPathComponent("foreign").path
    try FileManager.default.createSymbolicLink(atPath: foreign, withDestinationPath: "/usr/bin/false")
    do {
        try CLIInstallerService.uninstall(target: fixture.target, linkPath: foreign)
        Issue.record("expected pointsElsewhere")
    } catch let error as CLIInstallerService.InstallError {
        if case .pointsElsewhere = error {} else { Issue.record("wrong error: \(error)") }
    }
    #expect(FileManager.default.fileExists(atPath: foreign))

    let regular = fixture.root.appendingPathComponent("regular").path
    try "x".write(to: URL(fileURLWithPath: regular), atomically: true, encoding: .utf8)
    do {
        try CLIInstallerService.uninstall(target: fixture.target, linkPath: regular)
        Issue.record("expected blockedByFile")
    } catch let error as CLIInstallerService.InstallError {
        #expect(error == .blockedByFile(path: regular))
    }
}

@Test func privilegedScriptsRecheckPreconditions() {
    let install = CLIInstallerService.privilegedInstallScript(
        target: URL(fileURLWithPath: "/Applications/RunnerControl.app/Contents/Helpers/runner-control"),
        linkPath: "/usr/local/bin/runner-control"
    )
    #expect(install.contains("ln -sf"))
    #expect(install.contains("not a symlink, refusing"))
    #expect(install.contains("[ -x \"$dest\" ]"))
    let uninstall = CLIInstallerService.privilegedUninstallScript(
        target: URL(fileURLWithPath: "/Applications/RunnerControl.app/Contents/Helpers/runner-control"),
        linkPath: "/usr/local/bin/runner-control"
    )
    #expect(uninstall.contains("points elsewhere, refusing"))
    #expect(uninstall.contains("[ -L \"$link\" ] || exit 0"))
    let wrapped = CLIInstallerService.privilegedAppleScript(shell: "echo \"hi\"", prompt: "Prompt \"x\"")
    #expect(wrapped.contains("with administrator privileges"))
    #expect(wrapped.contains("\\\"hi\\\""))
    #expect(wrapped.contains("Prompt \\\"x\\\""))
}

// MARK: - Installer cross-process lease (flock)

@Test func installRootLockRoundTrip() throws {
    // Same-process acquire/release/reacquire. flock does not refuse a second
    // lock from the SAME process, so cross-process refusal is covered by the
    // test below with a helper child holding the lock.
    let root = FileManager.default.temporaryDirectory.appendingPathComponent("RC-Lock-" + UUID().uuidString)
    defer { try? FileManager.default.removeItem(at: root) }
    let first = try RunnerInstallerService.lockInstallRoot(root, pathForError: root.path)
    #expect(first != nil)
    if let fd = first { close(fd) }
    let second = try RunnerInstallerService.lockInstallRoot(root, pathForError: root.path)
    #expect(second != nil)
    if let fd = second { close(fd) }
    #expect(FileManager.default.fileExists(atPath: root.appendingPathComponent(RunnerInstallerService.installerLockFileName).path))
}

@Test func installRootLockRefusesForeignProcessHolder() throws {
    // A child process holds the flock via the same primitive (sh + a tiny
    // Swift helper would need a build; flock(1) is absent on macOS, so the
    // child execs THIS test bundle's logic through an inline swift script
    // that opens + flock()s the file and sleeps). Fallback when swift is
    // unavailable: skip rather than fake the assertion.
    let root = FileManager.default.temporaryDirectory.appendingPathComponent("RC-LockX-" + UUID().uuidString)
    try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
    defer { try? FileManager.default.removeItem(at: root) }
    let lockPath = root.appendingPathComponent(RunnerInstallerService.installerLockFileName).path
    FileManager.default.createFile(atPath: lockPath, contents: nil)
    let helper = root.appendingPathComponent("hold.swift")
    try """
    import Foundation
    let fd = open(CommandLine.arguments[1], O_RDWR)
    precondition(fd >= 0 && flock(fd, LOCK_EX) == 0)
    print("HELD", terminator: "")
    fflush(stdout)
    sleep(20)
    """.write(to: helper, atomically: true, encoding: .utf8)
    let child = Process()
    child.executableURL = URL(fileURLWithPath: "/usr/bin/swift")
    child.arguments = [helper.path, lockPath]
    let out = Pipe()
    child.standardOutput = out
    child.standardError = FileHandle.nullDevice
    do {
        try child.run()
    } catch {
        // No swift runner in this environment: nothing to assert.
        return
    }
    defer { child.terminate() }
    // Watchdog: a stuck helper can never hang the suite (termination EOFs
    // the pipe and unblocks the read below).
    DispatchQueue.global().asyncAfter(deadline: .now() + 90) {
        if child.isRunning { child.terminate() }
    }
    // Wait until the child reports the held lock.
    var sawHeld = false
    let handle = out.fileHandleForReading
    while !sawHeld {
        let data = handle.availableData
        if data.isEmpty { break }
        if String(data: data, encoding: .utf8)?.contains("HELD") == true { sawHeld = true; break }
        if child.isRunning == false { break }
    }
    guard sawHeld else {
        // Helper could not start (offline swift, first-run delay): skip.
        return
    }
    do {
        let fd = try RunnerInstallerService.lockInstallRoot(root, pathForError: root.path)
        if let fd { close(fd) }
        Issue.record("expected installerBusy while a foreign process holds the lock")
    } catch let error as RunnerRegistration.RegistrationError {
        if case .installerBusy = error {} else { Issue.record("wrong error: \(error)") }
    }
}

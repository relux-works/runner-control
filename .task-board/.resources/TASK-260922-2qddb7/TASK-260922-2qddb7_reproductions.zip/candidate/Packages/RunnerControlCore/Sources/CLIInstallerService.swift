import Foundation

/// Installs the `runner-control` command-line companion shipped inside the
/// app bundle. The GUI button and the CLI's own `install-cli` command share
/// this service, so both install exactly the same binary.
///
/// The installed entry is always a symlink to the binary inside
/// `RunnerControl.app/Contents/Helpers/`, never a copy: Sparkle updates
/// replace the bundle, and the symlink follows automatically.
public enum CLIInstallerService {
    public static let commandName = "runner-control"
    public static let helpersSubpath = "Contents/Helpers/runner-control"
    public static let primaryLinkPath = "/usr/local/bin/runner-control"

    public static var fallbackLinkURL: URL {
        FileManager.default.homeDirectoryForCurrentUser
            .appendingPathComponent(".local/bin/runner-control")
    }

    public enum LinkStatus: Sendable, Equatable {
        /// Symlink exists and resolves to the expected binary.
        case installedCurrent
        /// Symlink exists but resolves elsewhere (foreign install).
        case installedOther(destination: String)
        /// Nothing at the link path.
        case missing
        /// A non-symlink file occupies the link path. Never touched.
        case blockedByFile
    }

    public enum InstallError: LocalizedError, Sendable, Equatable {
        case bundledBinaryMissing
        case needsAdmin(path: String)
        case blockedByFile(path: String)
        case pointsElsewhere(path: String, destination: String)
        case io(String)

        public var errorDescription: String? {
            switch self {
            case .bundledBinaryMissing:
                "The bundled \(commandName) binary is missing. Reinstall Runner Control."
            case .needsAdmin(let path):
                "Cannot write \(path) without administrator rights."
            case .blockedByFile(let path):
                "Refusing to replace \(path): it is not a symlink."
            case .pointsElsewhere(let path, let destination):
                "Refusing to remove \(path): it points at \(destination)."
            case .io(let message):
                message
            }
        }
    }

    /// The binary this installer manages: the Helpers executable inside the
    /// host app bundle. Nil when the host is not the shipped app layout
    /// (local dev builds without an embedded CLI).
    public static func bundledBinaryURL(hostBundle: Bundle = .main) -> URL? {
        guard let bundleURL = hostBundle.bundleURL as URL?,
              bundleURL.pathExtension == "app" else { return nil }
        let candidate = bundleURL.appendingPathComponent(helpersSubpath)
        var isDir: ObjCBool = false
        guard FileManager.default.fileExists(atPath: candidate.path, isDirectory: &isDir),
              !isDir.boolValue,
              FileManager.default.isExecutableFile(atPath: candidate.path) else { return nil }
        return candidate
    }

    /// The binary of the currently running process, for CLI self-install
    /// (`runner-control install-cli` links PATH at its own location).
    public static func currentExecutableURL() -> URL {
        URL(fileURLWithPath: CommandLine.arguments[0]).resolvingSymlinksInPath()
    }

    public static func status(linkPath: String, target: URL) -> LinkStatus {
        let values = try? URL(fileURLWithPath: linkPath).resourceValues(forKeys: [.isSymbolicLinkKey])
        if values?.isSymbolicLink == true {
            let destination = (try? FileManager.default.destinationOfSymbolicLink(atPath: linkPath)) ?? ""
            let resolved: String
            if destination.hasPrefix("/") {
                resolved = URL(fileURLWithPath: destination).resolvingSymlinksInPath().path
            } else {
                resolved = URL(fileURLWithPath: linkPath).deletingLastPathComponent()
                    .appendingPathComponent(destination).resolvingSymlinksInPath().path
            }
            if resolved == target.resolvingSymlinksInPath().path {
                return .installedCurrent
            }
            return .installedOther(destination: destination)
        }
        if FileManager.default.fileExists(atPath: linkPath) {
            return .blockedByFile
        }
        return .missing
    }

    /// Creates (or refreshes) the symlink. Refuses to replace non-symlinks.
    /// Throws `needsAdmin` when the directory is not writable.
    public static func install(target: URL, linkPath: String) throws {
        switch status(linkPath: linkPath, target: target) {
        case .installedCurrent:
            return
        case .blockedByFile:
            throw InstallError.blockedByFile(path: linkPath)
        case .installedOther, .missing:
            break
        }
        let linkURL = URL(fileURLWithPath: linkPath)
        let directory = linkURL.deletingLastPathComponent()
        do {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        } catch {
            throw InstallError.needsAdmin(path: linkPath)
        }
        guard FileManager.default.isWritableFile(atPath: directory.path) else {
            throw InstallError.needsAdmin(path: linkPath)
        }
        if (try? URL(fileURLWithPath: linkPath).resourceValues(forKeys: [.isSymbolicLinkKey]))?.isSymbolicLink == true {
            try? FileManager.default.removeItem(at: linkURL)
        }
        do {
            try FileManager.default.createSymbolicLink(atPath: linkPath, withDestinationPath: target.path)
        } catch {
            throw InstallError.io(error.localizedDescription)
        }
    }

    /// Removes the symlink only when it points at `target`. Never deletes
    /// regular files or foreign symlinks.
    public static func uninstall(target: URL, linkPath: String) throws {
        switch status(linkPath: linkPath, target: target) {
        case .missing:
            return
        case .blockedByFile:
            throw InstallError.blockedByFile(path: linkPath)
        case .installedOther(let destination):
            throw InstallError.pointsElsewhere(path: linkPath, destination: destination)
        case .installedCurrent:
            break
        }
        guard FileManager.default.isWritableFile(atPath: URL(fileURLWithPath: linkPath).deletingLastPathComponent().path) else {
            throw InstallError.needsAdmin(path: linkPath)
        }
        do {
            try FileManager.default.removeItem(atPath: linkPath)
        } catch {
            throw InstallError.io(error.localizedDescription)
        }
    }

    /// Shell script removing the link, but only when it is a symlink
    /// pointing exactly at `target`. Same refusal rules as `uninstall`.
    public static func privilegedUninstallScript(target: URL, linkPath: String) -> String {
        let link = linkPath.replacingOccurrences(of: "'", with: "'\\''")
        let dest = target.path.replacingOccurrences(of: "'", with: "'\\''")
        return """
        set -e
        link='\(link)'
        dest='\(dest)'
        [ -L "$link" ] || exit 0
        [ "$(readlink "$link")" = "$dest" ] || { echo "points elsewhere, refusing" >&2; exit 1; }
        rm "$link"
        """
    }

    /// Wraps a shell script in an osascript `do shell script ... with
    /// administrator privileges` invocation with a product prompt. Pure
    /// string building; the caller runs `/usr/bin/osascript -e` with it.
    public static func privilegedAppleScript(shell: String, prompt: String) -> String {
        let escapedShell = shell
            .replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "\"", with: "\\\"")
        let escapedPrompt = prompt
            .replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "\"", with: "\\\"")
        return "do shell script \"\(escapedShell)\" with administrator privileges with prompt \"\(escapedPrompt)\""
    }

    /// Shell script the GUI runs with administrator privileges for the
    /// primary location. Single-quoted paths; the script itself re-checks
    /// every precondition instead of trusting the caller.
    public static func privilegedInstallScript(target: URL, linkPath: String) -> String {
        let link = linkPath.replacingOccurrences(of: "'", with: "'\\''")
        let dest = target.path.replacingOccurrences(of: "'", with: "'\\''")
        return """
        set -e
        link='\(link)'
        dest='\(dest)'
        [ -x "$dest" ] || { echo "bundled binary missing" >&2; exit 1; }
        if [ -e "$link" ] && [ ! -L "$link" ]; then echo "not a symlink, refusing" >&2; exit 1; fi
        mkdir -p "$(dirname "$link")"
        ln -sf "$dest" "$link"
        """
    }
}

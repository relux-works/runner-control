import ArgumentParser
import Foundation

/// `runner-control`: headless companion to the Runner Control GUI app.
///
/// Every command boots the same Relux runtime the GUI uses and dispatches
/// the same effects, against the same Keychain service, catalog file, and
/// defaults domain. Either surface can sign in, register, power, and
/// configure; neither can see live in-memory state of the other (each
/// process re-reads persistence per invocation), so prefer one writer at
/// a time for catalog edits.
@main
public struct RunnerControl: AsyncParsableCommand {
    public static let configuration = CommandConfiguration(
        commandName: "runner-control",
        abstract: "Headless control for Runner Control runners (1:1 with the GUI).",
        discussion: """
            Shares the GUI app's GitHub session, catalog, and settings on this Mac.
            Global flags (--json, --yes) come after the subcommand:

              runner-control runners list --json
              runner-control runners off --all --yes
            """,
        subcommands: [AuthCommand.self, RunnersCommand.self, RegisterCommand.self, AppCommand.self]
    )

    public init() {}

    public static func main() async {
        do {
            var command = try parseAsRoot()
            if var asyncCommand = command as? AsyncParsableCommand {
                try await asyncCommand.run()
            } else {
                try command.run()
            }
        } catch {
            handle(error)
        }
    }

    static func handle(_ error: Error) -> Never {
        if let failure = error as? CLIFailure {
            if CommandLine.arguments.contains("--json") {
                Output.jsonError(failure.message)
            }
            Output.warn("runner-control: \(failure.message)")
            Foundation.exit(failure.code.rawValue)
        }
        RunnerControl.exit(withError: error)
    }
}
